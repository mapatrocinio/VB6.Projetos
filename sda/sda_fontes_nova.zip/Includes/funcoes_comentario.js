
var strBgColorCabec="#97DCDF";
var strBgColorDetalhe="#DEEEEF";

function addRow(objTabela, intTipo, objControl){
	/* 	intTipo assume :
		0 - COment�rio
		1 - Recomenda��o
	*/
	// 1� Parent -> TD / 2� Parent -> TR
	var objRow = objControl.parentElement.parentElement;
	var objCol
	var num_linha_insercao = objRow.rowIndex+1;
	var num_linha_insercao_aux = num_linha_insercao;
	//var intNumLinha=parseInt(form.txtTotal.value) + 1;
	//form.txtTotal.value = intNumLinha;
	if (intTipo==0){
		//coment�rio
		objRow = objTabela.insertRow(num_linha_insercao++);
		objRow.bgColor=strBgColorCabec;
		objRow.id="linha"
		objCol = objRow.insertCell()
		objCol.className="texto"
		objCol.align="center";
		objCol.id="coluna_numeracao"
		objCol.rowSpan=3
		objCol.innerHTML = ""

		objRow = objTabela.insertRow(num_linha_insercao++);
		objRow.bgColor=strBgColorDetalhe;
		objRow.id="linha"
		objCol = objRow.insertCell()
		objCol.className="texto"
		objCol.align="left";
		objCol.width="50%";
		objCol.innerHTML = "<STRONG>Coment�rio:</STRONG>"

		objCol = objRow.insertCell()
		objCol.className="texto"
		objCol.align="right";
		objCol.width="50%";
		objCol.innerHTML = objCol.innerHTML + "<input type='checkbox' checked name='chk_relatorio_coment' value='1'>Ir para relat�rio"
		objCol.innerHTML = objCol.innerHTML + "<input type='checkbox' name='chk_RPNC_Coment' value='1' onclick='javascript:clickRPNCComent(document.all.tblPrincipal, this);'>Ir para RPNC"
		
		objRow = objTabela.insertRow(num_linha_insercao++);
		objRow.bgColor=strBgColorDetalhe;
		objRow.id="linha"
		objCol = objRow.insertCell()
		objCol.className="texto"
		objCol.align="left";
		objCol.width="100%";
		objCol.colSpan=2;
		objCol.innerHTML = "<TEXTAREA name='txtComentario' rows='3' style='WIDTH: 100%;'></TEXTAREA>"
		objCol.innerHTML = objCol.innerHTML + "<input type='text' name='txtIndTipoDetalhe' value='C'>"
		
		objRow = objTabela.insertRow(num_linha_insercao++);
		objRow.bgColor=strBgColorDetalhe;
		objRow.id="linha"
		objCol = objRow.insertCell()
		objCol.className="texto"
		objCol.align="left";
		objCol.width="100%";
		objCol.colSpan=2;
		objCol.innerHTML = "<STRONG>Texto do RPNC:</STRONG>"
		objRow.style.display="none"
		
		objRow = objTabela.insertRow(num_linha_insercao++);
		objRow.bgColor=strBgColorDetalhe;
		objRow.id="linha"
		objCol = objRow.insertCell()
		objCol.className="texto"
		objCol.align="left";
		objCol.width="100%";
		objCol.colSpan=2;
		objCol.innerHTML = "<TEXTAREA name='txtComentarioRPNC' rows='3' style='WIDTH: 100%;'></TEXTAREA>"

		objRow.style.display="none"
	}else{
		//recomenda��o
		objRow = objTabela.insertRow(num_linha_insercao++);
		objRow.bgColor=strBgColorCabec;
		objRow.id="linha"
		objCol = objRow.insertCell()
		objCol.className="texto"
		objCol.align="center";
		objCol.id="coluna_numeracao"
		objCol.rowSpan=3
		objCol.innerHTML = ""

		objRow = objTabela.insertRow(num_linha_insercao++);
		objRow.bgColor=strBgColorDetalhe;
		objRow.id="linha"
		objCol = objRow.insertCell()
		objCol.className="texto"
		objCol.align="left";
		objCol.width="50%";
		objCol.innerHTML = "<STRONG>Recomenda��o:</STRONG>"

		objCol = objRow.insertCell()
		objRow.id="linha"
		objCol.className="texto"
		objCol.align="right";
		objCol.width="50%";
		objCol.innerHTML = "<input type='checkbox' checked name='chk_relatorio_recomend' value='1'>Ir para relat�rio"
		objCol.innerHTML = objCol.innerHTML + "<input checked type='checkbox' name='chk_apres_numeracao_recomend' value='1'>Apresentar Numera��o"
		
		objRow = objTabela.insertRow(num_linha_insercao++);
		objRow.bgColor=strBgColorDetalhe;
		objRow.id="linha"
		objCol = objRow.insertCell()
		objCol.className="texto"
		objCol.align="left";
		objCol.width="100%";
		objCol.colSpan=2;
		objCol.innerHTML = "<TEXTAREA name='txtRecomendacao' rows='3' style='WIDTH: 100%;'></TEXTAREA>"
		objCol.innerHTML = objCol.innerHTML + "<input type='text' name='txtIndTipoDetalhe' value='R'>"
		
	}
	//adicionar rodap�
	adicionarRodape(objTabela, num_linha_insercao);
	//ap�s adicionar linha, incrementar total
	atualizaTotais(objTabela);
	//setar foco no controle
	setar_foco(objTabela, num_linha_insercao_aux);
}


function adicionarRodape(objTabela, num_linha_insercao){
	var objRow, objCol
	var intQtdLinhas=objTabela.rows.length;
	objRow = objTabela.insertRow(num_linha_insercao);
	objRow.bgColor=strBgColorCabec;
	objCol = objRow.insertCell()

	objCol.className="texto"
	objCol.align="right";
	objCol.width="100%";
	objCol.colSpan=3;
	objCol.id="coluna_detalhe";
	objCol.innerHTML = "<a style='cursor: Hand' class='link_botao_rodape' onClick='javascript:addRow(document.all.tblPrincipal, 0, this);'>+ Coment�rios</a>";
	objCol.innerHTML = objCol.innerHTML + "<a style='cursor: Hand' class='link_botao_rodape' onClick='javascript:addRow(document.all.tblPrincipal, 1, this);'> + Recomenda��es</a>";
	if (intQtdLinhas!=0){
		objCol.innerHTML = objCol.innerHTML + "<a style='cursor: Hand' class='link_botao_rodape' onClick='javascript:removeRow(document.all.tblPrincipal, this);'> - Remover</a>";
	}
}

function removeRow(objTabela, objControl){
	// 1� Parent -> TD / 2� Parent -> TR
	var objRow = objControl.parentElement.parentElement;
	var blnExcluir=true;
	var blnPrimeiroItem=true;
	var i;
	
	for (i=objRow.rowIndex; blnExcluir==true; i--){
		if (objTabela.rows[i].id=='' && blnPrimeiroItem==false){
			blnExcluir=false;
			break;
		}
		objTabela.deleteRow(i);
		blnPrimeiroItem=false;
	}
	//atualizar totais
	atualizaTotais(objTabela)
}
function atualizaTotais(objTabela){
	var form=document.forms[0];
	var i,x=0;
	for (i=0; i<objTabela.rows.length; i++ ){
		if (objTabela.rows[i].cells[0].id=="coluna_numeracao"){
			//� coluna com total
			x++
			objTabela.rows[i].cells[0].innerHTML=x;
		}
		if (objTabela.rows[i].cells[0].id=="coluna_detalhe"&&i!=0){
			//colunas  detalhes diferente da primeira
			objTabela.rows[i].cells[0].innerHTML = "<a style='cursor: Hand' class='link_botao_rodape' onClick='javascript:addRow(document.all.tblPrincipal, 0, this);'>+ Coment�rios</a>";
			objTabela.rows[i].cells[0].innerHTML = objTabela.rows[i].cells[0].innerHTML + "<a style='cursor: Hand' class='link_botao_rodape' onClick='javascript:addRow(document.all.tblPrincipal, 1, this);'> + Recomenda��es</a>";
			objTabela.rows[i].cells[0].innerHTML = objTabela.rows[i].cells[0].innerHTML + "<a style='cursor: Hand' class='link_botao_rodape' onClick='javascript:removeRow(document.all.tblPrincipal, this);'> - Remover</a>";
		}
		if (objTabela.rows[i].cells.length==2){
			if (objTabela.rows[i].cells[1].children(1).name=="chk_RPNC_Coment"){
				//achou checkbox, mudar value
				objTabela.rows[i].cells[1].children(1).value=x;
			}
		}
	}
	form.txtTotal.value = x;
}

function clickRPNCComent(objTable, objCheck){
	// 1� Parent -> TD / 2� Parent -> TR
	var objRow = objCheck.parentElement.parentElement;
	//tornar campo decsr ata rpnc vis�vel/invis�vel
	if (objCheck.checked==true){
		//est� selecionando (exibir)
		objTable.rows[objRow.rowIndex+2].style.display=""
		objTable.rows[objRow.rowIndex+3].style.display=""
		objTable.rows[objRow.rowIndex-1].cells[0].rowSpan=5
	}else{
		//est� deselecionando (inibir)
		objTable.rows[objRow.rowIndex+2].style.display="none"
		objTable.rows[objRow.rowIndex+3].style.display="none"
		objTable.rows[objRow.rowIndex-1].cells[0].rowSpan=3
	}
}

function setar_foco(objTable, num_linha_insercao){
	var objCaixaTextoFoco;
	var i;
	for (i=0; i<objTable.rows[num_linha_insercao+2].cells[0].children.length; i++){
		if (objTable.rows[num_linha_insercao+2].cells[0].children[i].name == 'txtComentario' || objTable.rows[num_linha_insercao+2].cells[0].children[i].name == 'txtRecomendacao'){
			objTable.rows[num_linha_insercao+2].cells[0].children[i].focus();
		}
	}
}
