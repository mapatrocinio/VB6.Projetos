function AbreJanela(pagina){
	if(pagina=='ProcessoBuscar.asp')
	{
		if(document.frm.NumProcesso.value==''){
			msg = window.open(pagina,"Janela2","width=790,height=570,scrollbars=yes,top=0,left=0");
		}
		else{
			document.frm.submit();
		}
	}
	else
		msg = window.open(pagina,"Janela2","width=790,height=570,scrollbars=yes,top=0,left=0");
}

function verifica_resolucao(){
	if (screen.height > 600){
		document.all.Td_Desenvolvimento.height='210px';
	}else{
		document.all.Td_Desenvolvimento.height='260px';
	}
}


