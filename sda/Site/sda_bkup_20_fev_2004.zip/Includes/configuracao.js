//(c) Ger Versluis 2000 version 1.0, 1 november 2000

	//var NoOffFirstLineMenus=4; //N�mero de Itens do menu
	var LowBgColor='#BDBCBF'//'#c0c0c0'; //cor de fundo do menu (quando n�o selecionado)
	var HighBgColor='5d8097'; //cor de fundo do menu (quando selecionado)-#909090
	var FontLowColor='#333333'; //cor de fundo da fonte (quando n�o selecionado)
	var FontHighColor='#ffffff'; //cor de fundo da fonte (quando selecionado) - #c0c0c0
	var BorderColor='#909090'; //cor da borda
	var BorderWidth=0; //espessura da borda
	var BorderBtwnElmnts=1;
	var FontFamily="verdana"
	var FontSize=7.0;
	var FontBold=0;
	var FontItalic=0;
	var MenuTextCentered=0;
	var MenuCentered='left';
	var MenuVerticalCentered='top';
	var ChildOverlap=.1;
	var ChildVerticalOverlap=.4;
	var StartTop=117; //set vertical offset (alinhamento vertical do in�cio do menu)
	var StartLeft=11; //set horizontal offset (alinhamento horizontal do in�cio do menu)
	var VerCorrect=0;
	var HorCorrect=0;
	var LeftPaddng=4;
	var TopPaddng=0;
	var FirstLineHorizontal=1; //set menu layout (1=horizontal, 0=vertical) (N�o precisa nem comentar)
	var MenuFramesVertical=1;
	var DissapearDelay=250;
	var TakeOverBgColor=1;
	var FirstLineFrame='';
	var SecLineFrame='';
	var DocTargetFrame='';
	var WebMasterCheck=0;

//Menux=new Array("texto que ir� aparecer no menu","Link",nro de sub-elementos,altura,largura);
//see accompanying "config.htm" file for more information on structure of menus


